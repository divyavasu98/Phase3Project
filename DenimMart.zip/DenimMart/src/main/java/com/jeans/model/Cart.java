package com.jeans.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table

public class Cart {
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", cartName=" + cartName + ", qty=" + qty + ", jeans=" + jeans + "]";
	}

	@Id
	private int cartId;
	public int getCartId() {
		return cartId;
	}

	public Cart(int cartId, String cartName, int qty, List<Jeans> jeans) {
		super();
		this.cartId = cartId;
		this.cartName = cartName;
		this.qty = qty;
		this.jeans = jeans;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getCartName() {
		return cartName;
	}

	public void setCartName(String cartName) {
		this.cartName = cartName;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public List<Jeans> getShoes() {
		return jeans;
	}

	public void setShoes(List<Jeans> jeans) {
		this.jeans = jeans;
	}

	private String cartName;
	private int qty;  //Quantity
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER )
	@JoinTable(name = "cart_jeans",
	joinColumns = @JoinColumn(name="cartId"),
	inverseJoinColumns = @JoinColumn(name="jeansId"))
	private List<Jeans> jeans;
	

}
