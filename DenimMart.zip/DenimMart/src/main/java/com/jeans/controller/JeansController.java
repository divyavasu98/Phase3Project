package com.jeans.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jeans.model.Jeans;
import com.jeans.service.JeansService;

@RestController
public class JeansController {

	@Autowired
	private JeansService service;
	
	@PostMapping("/jeans")
	public Jeans addShoes(@RequestBody Jeans jeans) {
		return service.addJeans(jeans);
	}

	@PutMapping("/jeans")
	public Jeans updateJeans(@RequestBody Jeans jeans) {
		
		return service.updateJeans(jeans);
	}

	@GetMapping("/jeans/{id}")
	public Jeans getJeansById(@PathVariable int id) {
		
		return service.getJeansById(id);
	}
	
	@DeleteMapping("/jeans/{id}")
	public void deleteJeansById(@PathVariable int id) {
	 service.deleteJeansById(id);
		
	}
	@GetMapping("/jeans")
	public List<Jeans> getAllJeans() {
		return service.getAllJeans();
	}
	@GetMapping("/jeans/brand/{brand}")
	public List<Jeans> getJeansByBrand(@PathVariable String brand) {
		
		return service.getJeansByBrand(brand);
	}

	@GetMapping("/jeans/color/{color}")
	public List<Jeans> getJeansByColor(@PathVariable String color) {
	
		return service.getJeansByColor(color);
	}

	@GetMapping("/jeans/size/{size}")
	public List<Jeans> getJeansBySize(@PathVariable int size) {
		
		return service.getJeansBySize(size);
	}

	@GetMapping("/shoes/price/{price}")
	public List<Jeans> getJeansByPrice(@PathVariable int price) {
		
		return service.getJeansByPrice(price);
	}
}
