package com.jeans.service;

import java.util.List;

import com.jeans.model.Jeans;

public interface JeansService {
	
	public Jeans addJeans(Jeans jeans);
	public Jeans updateJeans(Jeans jeans);
	public Jeans getJeansById(int id);
	public void deleteJeansById(int id);
	public List<Jeans> getAllJeans();
	public List<Jeans> getJeansByBrand(String brand);
	public List<Jeans> getJeansByColor(String color);
	public List<Jeans> getJeansBySize(int size);
	public List<Jeans> getJeansByPrice(int price);

}
