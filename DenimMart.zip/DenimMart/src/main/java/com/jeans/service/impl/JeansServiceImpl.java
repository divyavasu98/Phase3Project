package com.jeans.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jeans.dao.JeansRepository;
import com.jeans.model.Jeans;
import com.jeans.service.JeansService;

@Service
public class JeansServiceImpl implements JeansService{
	
	@Autowired
	private JeansRepository dao;

	@Override
	public Jeans addJeans(Jeans jeans) {
		return dao.save(jeans);
	}

	@Override
	public Jeans updateJeans(Jeans jeans) {
		return dao.save(jeans);
	}

	@Override
	public Jeans getJeansById(int id) {
		return dao.findById(id).get();
	}

	@Override
	public void deleteJeansById(int id) {
		dao.deleteById(id);
	}

	@Override
	public List<Jeans> getAllJeans() {	
		return dao.findAll();
	}

	@Override
	public List<Jeans> getJeansByBrand(String brand) {
		return dao.findByBrand(brand);
	}

	@Override
	public List<Jeans> getJeansByColor(String color) {
	return dao.findByColor(color);
	}

	@Override
	public List<Jeans> getJeansBySize(int size) {
	return dao.findBySize(size);
	}

	@Override
	public List<Jeans> getJeansByPrice(int price) {
		return dao.findByPrice(price);
	}
}
