package com.jeans.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jeans.model.Jeans;

@Repository
public interface JeansRepository extends JpaRepository<Jeans, Integer> {
	public List<Jeans> findByBrand(String brand);
	public List<Jeans> findByColor(String color);
	public List<Jeans> findBySize(int size);
	public List<Jeans> findByPrice(int price);
}
